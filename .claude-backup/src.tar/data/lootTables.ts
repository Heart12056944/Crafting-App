import lootTablesJson from "./crafting/lootTables.json";

export type LootQuality = "common" | "rare" | "epic";
export type CreatureTier = "common" | "uncommon" | "rare" | "epic" | "boss";

export type LootEntry = {
  name: string;
  amount?: string;
  kind?: "material" | "item" | "tool" | "kit";
  // Relative chance within its quality pool. Missing = 1.
  weight?: number;
};

export type LootTable = {
  id: string;
  label: string;
  family: string;
  // Recipe set this creature belongs to (hidden with that set in the GM panel).
  set?: string;
  // Tier picked automatically when the GM chooses this creature.
  defaultTier?: CreatureTier;
  tables: Partial<Record<LootQuality, LootEntry[]>>;
};

export const creatureTierRules: Record<CreatureTier, {
  label: string;
  attempts: number;
  dc: number;
  weights: { noLoot: number; common: number; rare: number; epic: number };
}> = {
  common: { label: "Common Creature", attempts: 2, dc: 10, weights: { noLoot: 20, common: 74, rare: 5, epic: 1 } },
  uncommon: { label: "Uncommon Creature", attempts: 3, dc: 12, weights: { noLoot: 12, common: 63, rare: 20, epic: 5 } },
  rare: { label: "Rare Creature", attempts: 4, dc: 14, weights: { noLoot: 8, common: 42, rare: 35, epic: 15 } },
  epic: { label: "Epic Creature", attempts: 5, dc: 15, weights: { noLoot: 3, common: 27, rare: 40, epic: 30 } },
  boss: { label: "Boss Creature", attempts: 6, dc: 17, weights: { noLoot: 1, common: 19, rare: 35, epic: 45 } },
};

function e(name: string, kind: LootEntry["kind"] = "material"): LootEntry {
  const match = name.match(/^(.*?)\s+\((\d*d\d+|\d+)\)$/i);
  if (match) return { name: match[1].trim(), amount: match[2], kind };
  return { name, kind };
}

const builtInLootTables: LootTable[] = [
  {
    id: "skeleton",
    label: "Skeleton",
    family: "skeleton",
    tables: {
      common: [
        "Carved Bone", "Scrap Steel", "Basic Fiber", "Cloth", "Leather Scraps", "Bone Needle",
        "Twine (50ft.)", "Cloth Bolts", "Leather Cord", "Cotton Thread", "Wood Planks", "Resin",
        "Binding Agents", "Empty Vials (set of 3)", "Basic Weapon Components", "Basic Tool Kit",
        "Sharpening Kit", "Weaver's Tools", "Leatherworker's Tools", "Smith's Tools", "Mana Dust", "Blank Scrolls",
      ].map((name) => e(name, name.includes("Tools") || name.includes("Kit") ? "tool" : "material")),
      rare: [
        "Rusted Shortsword", "Chipped Spear", "Cracked Bone Club", "Old Dagger", "Tarnished Shield",
        "Pitted Handaxe", "Rusty Mace", "Splintered Light Crossbow", "Cracked Longbow", "Old Flintlock", "Worn Arcane Focus",
      ].map((name) => e(name, "item")),
      epic: [
        "Powderburn Musket", "Brine-Tuned Pistol", "Reefbreaker Blunderbuss", "Tidehook Harpoon",
        "Saltfang Shortsword", "Barnacle Guard Shield", "Mistwalker Cloak", "Kelpgrip Gloves", "Deepwater Ring",
        "Coral Edge Dagger", "Rustbite Musket", "Splintermouth Blunderbuss", "Quickflash Pistol",
        "Cracklefang Dagger", "Stormspine Spear", "Rainspark Flintlock",
      ].map((name) => e(name, "item")),
    },
  },
  {
    id: "blue-drake",
    label: "Blue Drake",
    family: "blue-dragon",
    tables: {
      common: [
        "Crackling Scale Fragments (1d4)", "Static-Charged Hide Scraps (1d4)", "Brittle Horn Shards (1d4)",
        "Drake Scales (1d4)", "Residual Lightning Gland", "Scorched Bone Splinters (1d6)",
        "Salt-Cracked Hide Scraps (1d4)", "Flicker Residue", "Minor Conductive Blood Sample",
      ].map((name) => e(name)),
      rare: [
        "Reinforced Drake Scale", "Charged Lightning Gland", "Conductive Blood Crystal", "Stormbound Tendon Coil",
        "Pressure-Forged Spine Segment", "Tempest Core Fragment", "Ionized Fang", "Flicker Core Cluster", "Stormcall Scale Cluster",
      ].map((name) => e(name)),
      epic: [
        "Large Reinforced Drake Scale", "Fully Intact Tempest Core", "Apex Lighting Gland", "Conductive Blood Reservoir",
        "Stormcall Spine (Primary Segment)", "Ionized Crest Horn", "Living Storm Essence", "Tempest Anchor Node",
        "Phase-Charged Thunder Sac",
      ].map((name) => e(name)),
    },
  },
  {
    id: "blue-half-dragon",
    label: "Blue Half-Dragon",
    family: "blue-dragon",
    tables: {
      common: [
        "Fractured Scale Fragments (1d4)", "Storm-Touched Hide Scraps (1d4)", "Residual Storm Gland", "Flicker Residue",
        "Cracked Horn Shards (1d4)", "Charred Bone Splinters (1d6)", "Charged Tendon Strips (1d4)",
        "Salt-Burnt Hide Scraps (1d4)", "Minor Conductive Blood Sample", "Unstable Scale Dust",
        "Nerve Filament Threads (1d4)", "Half-Dragon Scale",
      ].map((name) => e(name)),
      rare: [
        "Hardened Half-Dragon Scale", "Charged Storm Gland", "Conductive Blood Crystal", "Stormbound Tendon Coil",
        "Reinforced Spine Segment", "Ionized Fang", "Flicker Core Cluster", "Stormcall Scale Cluster", "Hybrid Energy Node",
      ].map((name) => e(name)),
      epic: [
        "Unstable Tempest Core", "Apex Storm Gland", "Condensed Conductive Blood Reservoir", "Stormcall Spine (Refined)",
        "Ionized Crest Horn", "Living Storm Essence", "Hybrid Core Node", "Phase-Charged Organ Cluster",
        "Draconic Mutation Core", "Volatile Lighting Heart Fragment",
      ].map((name) => e(name)),
    },
  },
  {
    id: "blue-dragon-wyrmling",
    label: "Blue Dragon Wyrmling",
    family: "blue-dragon",
    tables: {
      common: [
        "Dragon Scale Fragments (1d4)", "Charged Dragonhide Scraps (1d4)", "Crackling Horn Shards (1d4)",
        "Minor Lighting Gland", "Dragonbone Splinters (1d6)", "Residual Storm Essence", "Conductive Blood Droplets",
        "Flicker Residue", "Ionized Nerve Threads (1d4)", "Scaled Membrane Strips (1d4)",
      ].map((name) => e(name)),
      rare: [
        "Blue Dragon Scale", "Charged Lighting Gland", "Conductive Blood Crystal", "Stormbound Tendon Coil",
        "Reinforced Dragonbone Segment", "Tempest Core Fragment", "Ionized Fang", "Stormcall Crest Fragment", "Draconic Energy Node",
      ].map((name) => e(name)),
      epic: [
        "Young Tempest Core (Incomplete)", "Apex Lighting Gland (Juvenile)", "Condensed Conductive Blood Reservoir",
        "Stormcall Spine Segment", "Ionized Crest Horn", "Living Storm Essence", "Draconic Core Node",
        "Pure Lighting Organ Cluster", "Stormheart Fragment",
      ].map((name) => e(name)),
    },
  },
  {
    id: "young-blue-dragon",
    label: "Young Blue Dragon",
    family: "blue-dragon",
    tables: {
      common: [
        "Dragon Scale Fragments (Refined) (1d4)", "Charged Dragonhide Strips (1d4)", "Reinforced Horn Shards (1d4)",
        "Residual Lighting Gland", "Dense Dragonbone Splinters (1d6)", "Storm Essence Residue", "Conductive Blood Droplets",
        "Flicker Residue", "Ionized Nerve Threads (1d4)", "Scaled Membrane Strips (1d4)",
      ].map((name) => e(name)),
      rare: [
        "Blue Dragon Scale (Reinforced)", "Apex Lighting Gland", "Conductive Blood Crystal", "Stormbound Tendon Coil",
        "Reinforced Dragonbone Segment", "Tempest Core (Stable)", "Ionized Fang", "Stormcall Crest", "Draconic Energy Node",
      ].map((name) => e(name)),
      epic: [
        "Perfect Tempest Core", "Supreme Lighting Gland", "Grand Conductive Blood Reservoir", "Stormcall Spine (Complete)",
        "Ionized Crown Horn", "Living Storm Essence (Pure)", "Dragonheart (Stormbound)", "Primal Lighting Organ Cluster",
        "Tempest Anchor Core",
      ].map((name) => e(name)),
    },
  },
  {
    id: "giant-wolf-spider",
    label: "Giant Wolf Spider",
    family: "spider",
    tables: {
      common: [
        "Thin Webbing Bundle (1d4)", "Spider Silk Strands (1d4)", "Small Chitin Fragments (1d4)",
        "Minor Venom Residue", "Hair Bristle Clumps", "Lightweight Leg Segments", "Organic Binding Fibers",
        "Silk Membrane Scraps", "Dried Venom Trace",
      ].map((name) => e(name)),
      rare: [
        "Basic Venom Sac", "Thick Webbing Bundle", "Hardened Chitin Plate (Small)", "Silk Gland (Minor)",
        "Reinforced Leg Segment", "Adhesive Silk Core", "Concentrated Venom Droplet", "Dense Web Cluster",
      ].map((name) => e(name)),
      epic: [
        "Refined Venom Sac (Lesser)", "Silk Gland (Refined)", "Hardened Chitin Plate", "Elastic Web Core",
        "Concentrated Adhesive Node", "Neural Silk Filament", "Predator Instinct Node",
      ].map((name) => e(name)),
    },
  },
  {
    id: "giant-spider",
    label: "Giant Spider",
    family: "spider",
    tables: {
      common: [
        "Webbing Bundle (1d4)", "Thick Silk Strands (1d4)", "Chitin Fragments (1d4)", "Minor Venom Residue",
        "Bristle Hair Clumps", "Leg Segments", "Organic Binding Fibers", "Silk Membrane Sheets",
        "Dried Venom Trace", "Silk Thread Cluster",
      ].map((name) => e(name)),
      rare: [
        "Basic Venom Sac", "Thick Webbing Bundle", "Hardened Chitin Plate", "Silk Gland", "Reinforced Leg Segment",
        "Adhesive Silk Core", "Concentrated Venom Droplet", "Dense Web Cluster", "Flexible Chitin Layer",
      ].map((name) => e(name)),
      epic: [
        "Refined Venom Sac", "Advanced Silk Gland", "Reinforced Chitin Plate", "Elastic Web Core",
        "Concentrated Adhesive Node", "Neural Silk Filament", "Predator Instinct Node", "Venom Catalyst Organ", "Silkflow Core",
      ].map((name) => e(name)),
    },
  },
  {
    id: "phase-spider",
    label: "Phase Spider",
    family: "spider",
    tables: {
      common: [
        "Phase-Touched Silk Strands (1d4)", "Distortion Webbing Fragments (1d4)", "Faded Chitin Fragments (1d4)",
        "Residual Phase Essence", "Flicker Residue", "Warped Leg Segments", "Dimensional Membrane Scraps",
        "Unstable Silk Threads (1d4)", "Ether Residue Clumps", "Phase Dust",
      ].map((name) => e(name)),
      rare: [
        "Phase Silk Bundle", "Phase Gland", "Distortion Core Fragment", "Warped Chitin Plate",
        "Dimensional Tendon Coil", "Phase Residue Cluster", "Flicker Core Node", "Etheric Venom Sac",
        "Spatial Anchor Thread",
      ].map((name) => e(name)),
      epic: [
        "Phase Core", "Advanced Phase Silk", "Distortion Core", "Planar Membrane Node", "Phase-Touched Venom Sac",
        "Spatial Tear Filament", "Ether Heart Fragment", "Dimensional Anchor Node", "Phase Echo Organ",
      ].map((name) => e(name)),
    },
  },
  {
    id: "giant-spider-matriarch",
    label: "Giant Spider Matriarch",
    family: "spider",
    tables: {
      common: [
        "Thick Webbing Bundles (1d4)", "Reinforced Silk Strands (1d4)", "Dense Chitin Fragments (1d4)",
        "Residual Venom Gland", "Brood-Touched Hair Clumps", "Reinforced Leg Segments",
        "Organic Binding Fibers", "Silk Membrane Sheets", "Venom Residue Cluster", "Silk Thread Core",
      ].map((name) => e(name)),
      rare: [
        "Potent Venom Gland", "High-Tensile Silk Bundle", "Hardened Chitin Plate", "Advanced Silk Gland",
        "Reinforced Leg Core", "Adhesive Silk Core", "Concentrated Venom Sac", "Dense Web Cluster",
        "Flexible Chitin Layer",
      ].map((name) => e(name)),
      epic: [
        "Queen Silk Thread", "Apex Venom Core", "Reinforced Chitin (Superior)", "Brood Essence Sac",
        "Royal Spinneret", "Living Silk Core", "Venom Nexus Organ", "Broodmind Node", "Predator Instinct Core",
      ].map((name) => e(name)),
    },
  },
  {
    id: "merfolk-reaver",
    label: "Merfolk Reaver",
    family: "merfolk",
    tables: {
      common: [
        "Brittle Coral Shards (1d4)",
        "Wet Scale Clippings (1d4)",
        "Salty Slime Residue (1d4)",
        "Fin Membranes (1d4)",
        "Bone Needle Fragments (1d4)",
        "Sea-Glass Scraps (1d4)",
      ].map((name) => e(name)),
      rare: [
        "Hardened Shell Fragment",
        "Living Coral Branch",
        "Reaver’s Spear-Tip",
        "Bioluminescent Gland",
        "Siren’s Pearl (Minor)",
        "Aquatic Sinew",
      ].map((name) => e(name)),
      epic: [
        "Reinforced Reef Plate",
        "Tide-Caller Node (Minor)",
        "Siren Essence (Refined)",
        "Coral Core Fragment",
        "Shamanic Bone Carving",
      ].map((name) => e(name)),
    },
  },
  {
    id: "merfolk-tide-caller",
    label: "Merfolk Tide-Caller",
    family: "merfolk",
    tables: {
      common: [
        "Hardened Shell Fragment",
        "Living Coral Branch",
        "Siren’s Pearl (Minor)",
        "Bioluminescent Gland",
        "Tide-Caller Node (Minor)",
        "Aquatic Sinew",
        "Luminous Sea-Glass",
      ].map((name) => e(name)),
      rare: [
        "Ancient Deep-Pearl",
        "Tide-Caller's Heart Node",
        "Concentrated Siren Essence",
        "Reef-Spire Fragment",
        "Deep-Sea Essence",
        "Oceanic Binding Fiber",
      ].map((name) => e(name)),
      epic: [
        "Heart of the Sea Node",
        "Sovereign Tide-Core",
        "Ancient Reef-Core",
        "Abyssal Pearl (Pristine)",
        "Tide-Master’s Staff Fragment",
      ].map((name) => e(name)),
    },
  },
  {
    id: "coral-hulked-behemoth",
    label: "Coral-Hulked Behemoth",
    family: "behemoth",
    tables: {
      common: [
        "Brittle Coral Shards (1d6)",
        "Hardened Shell Fragment (1d6)",
        "Salty Slime Residue (1d6)",
        "Thick Chitin Fragments (1d6)",
        "Crustacean Meat (Raw) (1d6)",
        "Heavy Bone Segments (1d6)",
      ].map((name) => e(name)),
      rare: [
        "Reinforced Reef Plate",
        "Massive Behemoth Pincer",
        "Living Coral Branch (Large)",
        "Hardened Chitin Plate",
        "Behemoth Eye-Stalk",
      ].map((name) => e(name)),
      epic: [
        "Leviathan-Scratched Carapace",
        "Heart of the Sea Node",
        "Ancient Reef-Core",
        "Apex Mobility Core (Oceanic)",
        "Behemoth Soul-Pearl",
      ].map((name) => e(name)),
    },
  },
  {
    id: "reef-shark",
    label: "Reef Shark",
    family: "oceanic-shark",
    tables: {
      common: [
        "Torn Reefskin Strips (1d4)", "Saltwater Cartilage (1d4)", "Jagged Tooth Fragments (1d4)", "Slick Fin Membranes (1d4)", "Brine Blood Residue (1d4)", "Coral-Scored Hide (1d4)", "Shark Liver Chunks (1d4)", "Razor Gill Fibers (1d4)",
      ].map((name) => e(name)),
      rare: [
        "Reinforced Reefskin", "Serrated Shark Jaw", "Hunter’s Fin Blade", "Dense Cartilage Core", "Bloodscent Gland", "Reef Predator Eye",
      ].map((name) => e(name)),
      epic: [
        "Apex Reef Jawbone", "Living Predator Core", "Tidehunter Spine Segment", "Oceanic Frenzy Organ", "Reinforced Reef Carapace",
      ].map((name) => e(name)),
    },
  },
  {
    id: "hunter-shark",
    label: "Hunter Shark",
    family: "oceanic-shark",
    tables: {
      common: [
        "Torn Reefskin Strips (1d4)", "Reinforced Reefskin (1d4)", "Serrated Shark Teeth (1d4)", "Slick Fin Membranes (1d4)", "Bloodscent Residue (1d4)", "Dense Cartilage Fragments (1d4)", "Razor Gill Fibers (1d4)", "Hunter Muscle Strands (1d4)", "Coral-Scored Hide (1d4)",
      ].map((name) => e(name)),
      rare: [
        "Massive Hunter Jaw", "Reinforced Predator Fin", "Bloodscent Gland", "Oceanic Tendon Bundle", "Hunter Spine Segment", "Dense Cartilage Core", "Tidehunter Eye Cluster",
      ].map((name) => e(name)),
      epic: [
        "Apex Hunter Core", "Frenzied Blood Organ", "Living Tidehunter Node", "Reinforced Leviathan Cartilage", "Hunter King Jawplate", "Predator Instinct Core (Oceanic)",
      ].map((name) => e(name)),
    },
  },
  {
    id: "giant-shark",
    label: "Giant Shark",
    family: "oceanic-shark",
    tables: {
      common: [
        "Reinforced Reefskin (1d6)", "Serrated Shark Teeth (1d6)", "Dense Cartilage Fragments (1d6)", "Massive Bone Segments (1d6)", "Bloodscent Residue (1d6)", "Oceanic Tendon Bundle (1d6)", "Hunter Spine Segment (1d6)", "Thick Fin Membranes (1d6)", "Brine-Soaked Muscle Chunks (1d6)",
      ].map((name) => e(name)),
      rare: [
        "Leviathan Jaw Fragment", "Titanic Cartilage Plate", "Giant Predator Eye", "Reinforced Tidehunter Spine", "Abyssal Blood Gland", "Massive Hunter Fin", "Oceanic Crushing Tendon",
      ].map((name) => e(name)),
      epic: [
        "Leviathan Heart-Core", "Apex Oceanic Predator Core", "Deep-Sea Frenzy Node", "Titanic Jawbone Plate", "Living Abyssal Organ", "Sovereign Tidehunter Core", "Oceanic Apex Mobility Core",
      ].map((name) => e(name)),
    },
  },
  {
    id: "giant-crab",
    label: "Giant Crab",
    family: "oceanic-crab",
    tables: {
      common: [
        "Cracked Shell Fragments (1d4)", "Saltwater Chitin Shards (1d4)", "Brine-Stained Claw Pieces (1d4)", "Crustacean Meat (Raw) (1d4)", "Barnacle-Covered Carapace (1d4)", "Coastal Tendon Fibers (1d4)", "Sea-Slime Residue (1d4)", "Hardened Leg Segments (1d4)",
      ].map((name) => e(name)),
      rare: [
        "Reinforced Crab Carapace", "Massive Crushing Claw", "Dense Chitin Plate", "Oceanic Muscle Bundle", "Brineheart Organ", "Tidebreaker Shell Segment",
      ].map((name) => e(name)),
      epic: [
        "Leviathan Crab Shell", "Crushing Pincer Core", "Ancient Reef Carapace", "Apex Crustacean Node", "Titanic Claw Blade",
      ].map((name) => e(name)),
    },
  },
  {
    id: "giant-octopus",
    label: "Giant Octopus",
    family: "oceanic-octopus",
    tables: {
      common: [
        "Slick Tentacle Strips (1d4)", "Ink Residue Sac (1d4)", "Suction Cup Clusters (1d4)", "Flexible Membrane Sheets (1d4)", "Oceanic Nerve Fibers (1d4)", "Saltwater Tendon Strands (1d4)", "Deep-Sea Flesh Chunks (1d4)", "Camouflage Skin Scraps (1d4)",
      ].map((name) => e(name)),
      rare: [
        "Concentrated Ink Gland", "Reinforced Tentacle Core", "Adaptive Skin Membrane", "Oceanic Neural Cluster", "Deepwater Eye Orb", "Flexible Tendon Bundle",
      ].map((name) => e(name)),
      epic: [
        "Abyssal Ink Core", "Sovereign Tentacle Node", "Krakenblood Organ Fragment", "Living Camouflage Membrane", "Deep-Sea Neural Nexus",
      ].map((name) => e(name)),
    },
  }
];

// Creatures defined in crafting/lootTables.json (Blackspire, Undying Vigil, and any
// future set). One JSON row per creature per pool; grouped here into one table each.
type JsonLootPool = {
  id: string;
  creature: string;
  creatureTier: string;
  pool: string;
  set?: string;
  family?: string;
  entries: {
    weight: number;
    materialName: string;
    amount?: string;
    kind?: LootEntry["kind"];
  }[];
};

function slugifyCreature(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function titleCaseCreature(value: string) {
  return value.toLowerCase().replace(/(^|[\s-])([a-z])/g, (_, lead: string, letter: string) => lead + letter.toUpperCase());
}

function creatureTierFromLabel(label: string): CreatureTier {
  const value = label.toLowerCase();
  if (value.includes("boss")) return "boss";
  if (value.includes("epic")) return "epic";
  if (value.includes("uncommon")) return "uncommon";
  if (value.includes("rare")) return "rare";
  return "common";
}

const jsonLootTables: LootTable[] = (() => {
  const builtInIds = new Set(builtInLootTables.map((table) => table.id));
  const byCreature = new Map<string, LootTable>();

  for (const pool of lootTablesJson as JsonLootPool[]) {
    const id = slugifyCreature(pool.creature);
    if (builtInIds.has(id)) continue;

    let table = byCreature.get(id);
    if (!table) {
      table = {
        id,
        label: titleCaseCreature(pool.creature),
        family: pool.family || id,
        set: pool.set || "blackspire",
        defaultTier: creatureTierFromLabel(pool.creatureTier),
        tables: {},
      };
      byCreature.set(id, table);
    }

    const quality = pool.pool.toLowerCase();
    if (quality !== "common" && quality !== "rare" && quality !== "epic") continue;

    table.tables[quality] = pool.entries.map((entry) => ({
      name: entry.materialName,
      weight: entry.weight,
      amount: entry.amount,
      kind: entry.kind || "material",
    }));
  }

  return [...byCreature.values()];
})();

export const lootTables: LootTable[] = [...builtInLootTables, ...jsonLootTables];

// Picks one entry, respecting weights (entries without a weight count as 1).
export function pickWeightedLootEntry(entries: LootEntry[]): LootEntry {
  const total = entries.reduce((sum, entry) => sum + Math.max(0, entry.weight ?? 1), 0);
  if (total <= 0) return entries[Math.floor(Math.random() * entries.length)];

  let roll = Math.random() * total;
  for (const entry of entries) {
    roll -= Math.max(0, entry.weight ?? 1);
    if (roll < 0) return entry;
  }
  return entries[entries.length - 1];
}

export function rollWeightedLootQuality(tier: CreatureTier): LootQuality | "none" {
  const weights = creatureTierRules[tier].weights;
  const total = weights.noLoot + weights.common + weights.rare + weights.epic;
  let roll = Math.floor(Math.random() * total) + 1;
  if ((roll -= weights.noLoot) <= 0) return "none";
  if ((roll -= weights.common) <= 0) return "common";
  if ((roll -= weights.rare) <= 0) return "rare";
  return "epic";
}

export function rollDiceExpression(amount?: string) {
  if (!amount) return 1;
  const cleaned = amount.trim().toLowerCase();
  const dice = cleaned.match(/^(\d*)d(\d+)$/);
  if (dice) {
    const count = dice[1] ? Number(dice[1]) : 1;
    const sides = Number(dice[2]);
    return Array.from({ length: count }).reduce<number>((sum) => sum + Math.floor(Math.random() * sides) + 1, 0);
  }
  const flat = Number(cleaned);
  return Number.isFinite(flat) && flat > 0 ? flat : 1;
}

export function getLootTable(id: string) {
  return lootTables.find((table) => table.id === id) || lootTables[0];
}
